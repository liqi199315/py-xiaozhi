# 设备激活界面包
from .activation_window import ActivationWindow

__all__ = ["ActivationWindow"]
