"""
设置相关模块.
"""

from .settings_window import SettingsWindow

__all__ = ["SettingsWindow"]
