"""
音频设备设置组件.
"""

from .audio_widget import AudioWidget

__all__ = ["AudioWidget"]
