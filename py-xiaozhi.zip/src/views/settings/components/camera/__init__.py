"""
摄像头设置组件.
"""

from .camera_widget import CameraWidget

__all__ = ["CameraWidget"]
