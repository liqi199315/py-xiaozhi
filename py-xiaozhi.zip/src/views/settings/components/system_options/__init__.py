"""
系统选项设置组件.
"""

from .system_options_widget import SystemOptionsWidget

__all__ = ["SystemOptionsWidget"]
