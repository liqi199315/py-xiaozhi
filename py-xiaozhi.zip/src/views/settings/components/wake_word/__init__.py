"""
唤醒词设置组件.
"""

from .wake_word_widget import WakeWordWidget

__all__ = ["WakeWordWidget"]
