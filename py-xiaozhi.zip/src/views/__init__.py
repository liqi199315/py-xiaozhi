# Views包 - 所有PyQt界面组件
"""Views模块包含所有的PyQt界面组件.

- base: 基础组件和通用类
- activation: 设备激活界面
- settings: 设置界面
"""

__version__ = "1.0.0"
