# Components包 - GUI组件模块
"""
Components模块包含可复用的GUI组件
- system_tray: 系统托盘组件
"""

__version__ = "1.0.0"
