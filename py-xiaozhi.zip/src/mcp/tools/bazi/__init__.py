"""
八字命理分析工具模块。
"""

from .manager import get_bazi_manager

__all__ = ["get_bazi_manager"]
