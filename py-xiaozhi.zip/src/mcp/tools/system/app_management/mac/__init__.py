"""
macOS系统应用程序管理模块.
"""

from . import scanner

__all__ = ["scanner"]
