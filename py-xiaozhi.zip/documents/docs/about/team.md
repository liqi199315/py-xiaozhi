---
page: true
title: Py-xiaozhi团队
layout: home
---

<script setup>
import TeamPage from './team/TeamPage.vue'
</script>

<TeamPage />
