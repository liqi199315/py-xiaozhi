// 赞助者数据
export default {
  sponsors: [
    {
      name: "ZhengDongHang",
      url: "https://github.com/ZhengDongHang",
      image: "https://avatars.githubusercontent.com/u/193732878?v=4",
    },
    {
      name: "YANG-success-last",
      url: "https://github.com/YANG-success-last",
      image: "https://tuchuang.junsen.online/i/2025/03/28/2kzeks.jpg",
    },
    {
      name: "李洪刚",
      url: "https://github.com/SmartArduino",
      image: "https://tuchuang.junsen.online/i/2025/03/28/2kfo2p.jpg",
    },
    {
      name: "kejily",
      url: "https://github.com/kejily",
      image: "https://tuchuang.junsen.online/i/2025/03/28/2mpif8.jpg",
    },
    {
      name: "thomas",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/03/28/2km1gm.jpg",
    },
    {
      name: "吃饭叫我",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/03/28/2k0i12.jpg",
    },
    {
      name: "留白",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/03/30/115fqut.jpg",
    },
    {
      name: "*腾",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/04/03/v259c.png",
    },
    {
      name: "张海峰",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/04/14/mcp32y.jpg",
    },
    {
      name: "邹一达",
      url: "https://github.com/zyddsg159357",
      image: "https://tuchuang.junsen.online/i/2025/04/14/mcd4q2.jpg",
    },
    {
      name: "折木",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/04/17/3qrbs4.jpg",
    },
    {
      name: "arron",
      url: "https://github.com/kernelj",
      image: "https://tuchuang.junsen.online/i/2025/04/20/ppbiy2.jpg",
    },
    {
      name: "Hpp 💦",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/04/27/5a1ood.jpg",
    },
    {
      name: "985",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/04/27/59h2g1.jpg",
    },
    {
      name: "章振海",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/07/21/mdu5ou.png",
    },
    {
      name: "汪汪",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/07/21/mckypx.png",
    },
    {
      name: "万维赛博Ai智能科技",
      url: "",
      image: "https://tuchuang.junsen.online/i/2025/08/13/hgsdn8.png",
    },
  ],
};
