import DefaultTheme from 'vitepress/theme'
import './styles/index.css'
import './styles/custom.scss'

export default {
  ...DefaultTheme,
}
